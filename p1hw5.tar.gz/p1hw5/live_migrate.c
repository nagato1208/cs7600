#include <sys/socket.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <signal.h>
//enum command { MEM_MAP, MEM_UNMAP };
char *command = "MEM_MAP";
void process_conn_client(int s){
    char buf[256];
    char *mycmd = command;
    //enum command mycmd;
    //mycmd = MEM_MAP;
    int size;
    int i=0;
    printf("Working in sending data from client!\n");
    while(i++<10){
        //printf("round: %d...\n", i);
        write(1, "------", sizeof("------"));
        write(s, mycmd, sizeof(mycmd));
        size = read(s, buf, sizeof(buf));
        write(1, buf, size);
        //write(1, "\n", sizeof(char*));
    }
    printf("OK, 10 rounds of interacion has finished!\n");
}



int main(int argc, char**argv)
{
    int s;
    sleep(10);
    struct sockaddr_in server_addr;
    int err;
    //printf("Working in live mig... \n");
    sigaction(SIGPIPE, &(struct sigaction){SIG_IGN}, NULL);
    s = socket(AF_INET, SOCK_STREAM, 0);
    if(s < 0){
        printf("socket error\n");
        return -1;
    }
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    //server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_addr.s_addr = (int)inet_addr(argv[1]);
    //server_addr.sin_port = htons(0);
    server_addr.sin_port =  atoi(argv[2]);
    char t1[32];
    char t2[32];
    sprintf(t1, "---address: %d ", server_addr.sin_addr.s_addr);
    sprintf(t2, "---port: %d ", server_addr.sin_port);
    //printf("addr : %d\n", server_addr.sin_addr);
    //printf("port : %d\n", server_addr.sin_port);
    write(1, t1, sizeof(t1));
    write(1, t2, sizeof(t2));
    if(connect(s, (struct sockaddr*)&server_addr, sizeof(struct sockaddr)) == -1)
        perror("Failed to connect!");
    process_conn_client(s);
    close(s);
    return 0;
}
