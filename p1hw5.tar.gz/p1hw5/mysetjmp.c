//  Copyright (c) 2017 Gene Cooperman
//  This may be freely copied and modified as long as this copyright remains.
//  The software is provided "as is", without warranty of any kind.

// EXPORTS:  mysetjmp(myjmp_buf_t env) and mylongjmp(myjmp_buf_t env, int val)

#include <ucontext.h>
#include "mysetjmp.h"

#if 0
// This is replaced by a macro in mysetjmp.h.  See the comment there.
int mysetjmp(myjmp_buf_t env) {
  env[0].mysetjmp_val = 0;
  env[0].mysetjmp_ptr = &(env[0].mysetjmp_val);
  getcontext(&(env[0].context));
  return *(env[0].mysetjmp_ptr);
}
#endif

void mylongjmp(myjmp_buf_t env, int val) {
  if (val == 0) {
    *(env[0].mysetjmp_ptr) = 1;
  } else {
    *(env[0].mysetjmp_ptr) = val;
  }
  setcontext(&(env[0].context));
}
