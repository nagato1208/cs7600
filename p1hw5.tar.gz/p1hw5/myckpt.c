#include <signal.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <netinet/in.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdbool.h>
#include "mysetjmp.h"


void handler(int sig){
   int x = 0;
   myjmp_buf_t env;
   x = mysetjmp(env);
   if(!x){
       ;
       } 
    else
        return;
  char buf1[256], buf2[256];
  char libckpt_host[256];
  int libckpt_host_fd = open("libckpt-host.txt", O_RDONLY);
  int rc = read(libckpt_host_fd, libckpt_host, sizeof(libckpt_host));
  if (*(libckpt_host + strlen(libckpt_host) -1) == '\n') {
      libckpt_host[strlen(libckpt_host)-1] = '\0';
  }

  close(libckpt_host_fd);
  int listenfd;
  int connfd;
  int len = 0;
  struct sockaddr_in serv_addr;
  struct sockaddr_in cli_addr;
  char buffer[256];
  // Create socket endpoint of server
  listenfd = socket(AF_INET, SOCK_STREAM, 0);
  if(listenfd < 0){
    printf("socket error!\n");
    exit(1);  
  }
 
  
  //serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port = htons(0);
  bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
  // Discover what listener_port was assigned:
  int addrlen = sizeof(serv_addr);
  if(getsockname(listenfd, &serv_addr, &addrlen) == -1)
      perror("getsockname failed");
  //listener_port = serv_addr.sin_port;
  
  listen(listenfd, 10);

  char ssh_cmd[256];
  char *cwd = getcwd(buf1, sizeof(buf1));

  //int hst = gethostname(buf2, sizeof(buf2));
  printf("cwd: %s\n", cwd);
  printf("hst: %s\n", inet_ntoa(serv_addr.sin_addr));
  printf("port: %d\n", serv_addr.sin_port);
  sprintf(ssh_cmd, "ssh %s %s/live_migrate %s %d &", libckpt_host, cwd, inet_ntoa(serv_addr.sin_addr), serv_addr.sin_port);
  //sprintf(ssh_cmd, "ssh %s /home/zhangxy/tmp %s %d ", "zhangxy@login.ccs.neu.edu", inet_ntoa(serv_addr.sin_addr), serv_addr.sin_port);
  printf("%s\n", ssh_cmd);
  
  system(ssh_cmd);
   
   int clilen = sizeof(struct sockaddr); 
  connfd = accept(listenfd, (struct sockaddr*)&cli_addr, &clilen);
    
  if (connfd < 0)
  {
     perror("ERROR on accept");
     exit(1);
  }
  
  //pid_t child;
  //child = fork();
  //if(child == 0)
  int i = 0;
   while((len=recv(connfd, buffer, sizeof(buffer), 0))>0)
  {
    sprintf(buffer, "no.%d", i);
    //strcpy(buffer, "no_map ");
    printf("\nThe server send: %s\n", buffer);
    if(send(connfd, buffer, len, 0)<0)
    {
        perror("write");
        exit(1);
        }
    i++;
  }
  //sleep(100);
  
    //sleep(100);
}

__attribute__ ((constructor))
            void myconstructor() {
              signal(SIGUSR2, handler);
            }
