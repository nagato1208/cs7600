#include <stdio.h>
   
int main(int argc, char *argv[]) {
       int i = 0;
       while(++i) {
           printf("%d\n",i);
           sleep(1);
       }
   }

