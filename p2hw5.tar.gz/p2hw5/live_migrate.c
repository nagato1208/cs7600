#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <signal.h>
#include <sys/mman.h>
#include "mysetjmp.h"
char *unmap_start, *unmap_end;
typedef char * VA;

char mtcp_read_char (int fd) {
    char c; 
    int rc;
    do {
        rc = read (fd, &c, 1);
    } while ( rc == -1);

    if (rc <= 0) 
        return (0);
    return (c);
}
char mtcp_read_hex (int fd, VA *virt_mem_addr) {
    char c;
    unsigned long int v;
    v = 0;
    while (1) {
        c = mtcp_read_char(fd);
        if ((c >= '0') && (c <= '9')) c -= '0';
        else if ((c >= 'a') && (c <= 'f')) c -= 'a' - 10;
        else if ((c >= 'A') && (c <= 'F')) c -= 'A' - 10; 
        else break; 
        v = v * 16 + c;
        //p++;
    }
    *virt_mem_addr = (VA)v;
    return (c);
}

char * move_myrestart(){
     void *new_start, *new_end;
     unsigned long long size, new_size;
     int fd;
     char *new_stack_ptr;
     char buf[1024];
     char my_stack_start[16], my_stack_end[16], my_stack_name[8];
     unsigned char *example_start = (unsigned char *)0x6700000;
     unsigned char *example_end = (unsigned char *)0x6701000;
     char *start, *end;
     char tmp;
     new_size =1000000;

     
     fd = open("/proc/self/maps", O_RDONLY);
     //printf("\nOpen self maps finished...");
     if(fd < 0)
         {perror("Open self maps failed!"); exit(1);}
     while(1){
         mtcp_read_hex(fd, &start);
         mtcp_read_hex(fd, &end);
         while((tmp = mtcp_read_char(fd)) != '\n'){
             if((tmp == '[')) {
                 if((tmp = mtcp_read_char(fd)) == 's')
                   {  fflush(stdout);
                     //printf("\nHit!");
                  goto Hit;}
             }
             } 
     }
Hit:
     //printf(": %x - %x", start, end);
     unmap_start = start;
     unmap_end = end;

     new_stack_ptr = mmap(example_start, new_size, PROT_READ|PROT_WRITE, MAP_ANONYMOUS|MAP_PRIVATE, -1, 0);
     if(new_stack_ptr == MAP_FAILED)
         {perror("Reseting stack failed!"); exit(1);}
     //printf("\nMapping to new stack ptr finished...");
 
     
     memcpy(new_stack_ptr, start, end - start);
     new_stack_ptr = new_stack_ptr + (end -start);
     write(1,"\n---The old stack has been moved to new place...\n", sizeof("\n---The old stack has been moved to new place...\n"));

  return new_stack_ptr;
}

void restore_memory(int s){
    munmap(unmap_start, unmap_end - unmap_start);
    //printf("\n---Now the old stack's space has been cleared...");
    unsigned long long st;
    unsigned long long en;
        int i = 0;
    char tmp[64];
    char *p;
    myjmp_buf_t env;
    memset(tmp,0,sizeof(tmp)); 
    //printf("\nNow read context data...\n");
    recv(s, &env, sizeof(env), MSG_WAITALL);
     
    sprintf(tmp, "---Got %d size context data...\n", sizeof(env));
    write(1, tmp, sizeof(tmp));
    write(s, "---Context has been recived by live---", sizeof("---Context has been recived by live---"));
    char start[64], end[64];
    while(i < 8){
        recv(s, &st, sizeof(st),MSG_WAITALL);
        recv(s, &en, sizeof(en),MSG_WAITALL) ;
        
        //sleep(3);
        //st = strtoull(start, NULL, 16);
        //en = strtoull(end, NULL, 16);
        sprintf(tmp, "---read address: %x  %x\n", st, en);
        write(1, tmp ,sizeof(tmp));

        ssize_t len = en - st;
        p = mmap((char *)st, len, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_ANONYMOUS|MAP_PRIVATE, -1, 0);
        if(p == MAP_FAILED)
            perror("Mapping failed!");

        recv(s, p, len, MSG_WAITALL);

        sprintf(tmp, "---Readed %d size of data...\n", len);
        write(1, tmp, sizeof(tmp));
        i++;
        }
        
        write(1, "---Now set context data...\n", sizeof("---Now set context data...\n"));
        mylongjmp(env, 1);
}




int main(int argc, char**argv)
{
    int s;
    struct sockaddr_in server_addr;
    int err;
    //sleep(3); 
    
    sigaction(SIGPIPE, &(struct sigaction){SIG_IGN}, NULL);
    s = socket(AF_INET, SOCK_STREAM, 0);
    if(s < 0){
        printf("socket error\n");
        return -1;
    }
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    //server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_addr.s_addr = (int)inet_addr(argv[1]);
    //server_addr.sin_port = htons(0);
    server_addr.sin_port =  atoi(argv[2]);
    //printf("---live-addr : %d\n", server_addr.sin_addr);
    //printf("---live-port : %d\n", server_addr.sin_port);
    if(connect(s, (struct sockaddr*)&server_addr, sizeof(struct sockaddr)) == -1)
        perror("Failed to connect!");
    
    write(1,"---Connected!+++", sizeof("---Connected!+++"));
    //sleep(3);

    
    char *new_stack_ptr = move_myrestart();
    asm volatile ("mov %0,%%rsp;" : : "g" (new_stack_ptr) : "memory");
    //sleep(5);
    restore_memory(s);
    close(s);
    return 0;
}
