#include <signal.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <netinet/in.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <setjmp.h>
#include <stdbool.h>
#include "mysetjmp.h"


void handler(int sig){
   int x = 0;
   myjmp_buf_t env;
     char buf1[256], buf2[256];
  char libckpt_host[256];
  int libckpt_host_fd = open("libckpt-host.txt", O_RDONLY);
  int rc = read(libckpt_host_fd, libckpt_host, sizeof(libckpt_host));
  close(libckpt_host_fd);
  if (*(libckpt_host + strlen(libckpt_host) -1) == '\n') {
      libckpt_host[strlen(libckpt_host)-1] = '\0';
  }
  int listenfd;
  int connfd;
  int len = 0;
  struct sockaddr_in serv_addr;
  struct sockaddr_in cli_addr;
  char buffer[256];
  // Create socket endpoint of server
  listenfd = socket(AF_INET, SOCK_STREAM, 0);
  if(listenfd < 0){
    printf("socket error!\n");
    exit(1);  
  }
 
  
  //serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port = htons(0);
  bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
  // Discover what listener_port was assigned:
  int addrlen = sizeof(serv_addr);
  if(getsockname(listenfd, &serv_addr, &addrlen) == -1)
      perror("getsockname failed");
  //listener_port = serv_addr.sin_port;
  
  listen(listenfd, 10);

  char ssh_cmd[256];
  char *cwd = getcwd(buf1, sizeof(buf1));

  //int hst = gethostname(buf2, sizeof(buf2));
  printf("cwd: %s\n", cwd);
  printf("hst: %s\n", inet_ntoa(serv_addr.sin_addr));
  printf("port: %d\n", serv_addr.sin_port);
  sprintf(ssh_cmd, "ssh %s %s/live_migrate %s %d &", libckpt_host, cwd, inet_ntoa(serv_addr.sin_addr), serv_addr.sin_port);
  //sprintf(ssh_cmd, "./live_migrate %s %s &", inet_ntoa(serv_addr.sin_addr), serv_addr.sin_port);
  printf("%s\n", ssh_cmd);
  system(ssh_cmd);
    printf("ssh cmd has been run!\n");

  int clilen = sizeof(struct sockaddr); 
  connfd = accept(listenfd, (struct sockaddr*)&cli_addr, &clilen);
  printf("Connected!\n");    
  if (connfd < 0)
  {
     perror("ERROR on accept");
     exit(1);
  }
    
   x = mysetjmp(env);
   if(!x){
       send(connfd, &env, sizeof(env), 0);
       } 
    else
        {   printf("Welcome back\n");
            return;}
    char tmp[64];
    read(connfd, tmp, sizeof(tmp));
    printf("Msg from live: %s", tmp); 
    FILE *fp = fopen("/proc/self/maps", "r");
    if (fp == NULL)
        perror("file read/open failed!");
    int i=0;
    char buf[1024];
    char start_addr[64], end_addr[64], tmp_perms[8], offset[16];
    while (fgets(buf, 1024, fp)){
        printf("\nOriginal data: %s", buf);
        if (sscanf(buf, "%[0-9a-z]-%[0-9a-z] %[r|w|p|x|-] %[0-9a-z]", start_addr, end_addr, tmp_perms, offset) > 0){
            //printf("\nstart: %s; end: %s; perms: %s\n", start_addr, end_addr, tmp_perms);
            unsigned long long start = strtoull(start_addr, NULL, 16);
            unsigned long long end = strtoull(end_addr, NULL, 16);
            printf("send addr: %x %x, size: %d\n", start, end, end-start);
            //send(connfd, start_addr, sizeof(start_addr), 0);
            //send(connfd, end_addr, sizeof(end_addr), 0);
                //sleep(2);
                send(connfd, &start, sizeof(start), 0);
                send(connfd, &end, sizeof(end), 0);
                send(connfd, (char *)start, (char*)end-(char*)start, 0);
                
            //fwrite((char*)(lines->start_addr), (char*)(lines->end_addr)-(char*)(lines->start_addr), 1, fp2);
            printf("Finished sending %d size of data...\n", end-start);
            i++;
        }
    }
    printf("Finished sending data! Now leave handler and continue printing...\n");
    fclose(fp);
    //while(1);
}

__attribute__ ((constructor))
            void myconstructor() {
              signal(SIGUSR2, handler);
            }
