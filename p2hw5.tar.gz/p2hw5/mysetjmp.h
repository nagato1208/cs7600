//  Copyright (c) 2017 Gene Cooperman
//  This may be freely copied and modified as long as this copyright remains.
//  The software is provided "as is", without warranty of any kind.

#include <ucontext.h>
typedef struct myjmp_buf{
          ucontext_t context;
          int mysetjmp_val;
          int *mysetjmp_ptr;
        } myjmp_buf_t[1];

// IMPORTANT:  mysetjmp() must be compiled inline.  If it were not inline,
//   would create a new call frame for itself, and then the stack pointer
//   it would point to the new call frame, while the user would have saved
//   the user stack only as it existed in the caller of mysetjmp().
#if 0
// gcc 4.8 will not inline a function that uses getcontext().
inline int mysetjmp (myjmp_buf_t env) __attribute__((always_inline));
#endif

// FIXME:  Must save and restore the register %fs for x86_64.
// FIXME:  Note that recent glibc's come pre-compiled with stack protection.
//         So, more will be needed when returning from a function like sleep().
//         However, DMTCP is not affected by either of the above issues.
#define mysetjmp(env)            \
({                               \
  env[0].mysetjmp_val = 0;        \
  env[0].mysetjmp_ptr = &(env[0].mysetjmp_val);        \
  getcontext(&(env[0].context)); \
  *(env[0].mysetjmp_ptr);            \
})

void mylongjmp(myjmp_buf_t env, int val);
